import React from 'react'

const ShimmerCard = () => {
  return (
    <div className='flex flex-wrap'>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>
      <div className='m-2 p-2 w-[193px] h-[300px] flex flex-col justify-between items-center border-2 border-solid border-gray-200 cursor-pointer bg-gray-300 hover:border-gray-300'></div>

    </div>
  )
}

export default ShimmerCard
