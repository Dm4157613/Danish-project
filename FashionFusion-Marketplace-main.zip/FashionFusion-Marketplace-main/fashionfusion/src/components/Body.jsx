
import React from 'react'
import Products from './Products'
import Carousel from './Carousel'

const Body = () => {
  return (
    <>
    <Carousel/>
    <Products/>
    </>
  )
}

export default Body
