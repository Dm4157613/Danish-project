

const languagePrefernce = {
    en : {
        searchPlaceholder:"Search FashionFusion",
        city : "Pune",
        cart : "Cart"   
    },
    hin : { 
        searchPlaceholder :"ढूंढिए FashionFusion",
        city : "पुणे",
        cart : "कार्ट"
    },
    mar : {
        searchPlaceholder :"शोधा FashionFusion",
        city : "पुणे", 
        cart : "कार्ट"
    },
};

export {languagePrefernce};